<?php
include("dbconnection.php")


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
     <h1>Sing Up</h1>
     <form action="" method="post" name="1">
        <table border="1" cellspacing="0">
        <tr>
            <td colospan=2 align="center">Signup Form</td>
        </tr>
        <tr>
            <td><label>FirstName</label></td>
            <td><input type="text" name="fname" required></td>
        </tr>
        <tr>
            <td><label>LastName</label></td>
            <td><input type="text" name="lname" required></td>
        </tr>
        <tr>
         <td><label>Gender</label></td>
         <td><select name="gender" required style="withd: 165px;">
          <option value="">Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
         </select></td>
         </tr>
         <tr>
           <td><label>age</label></td>
          <td><input type="number" name="age" min="10" max="50" required style="withd: 165px";></td>
         </tr>
         <tr>
            <td><label>Email</label></td>
            <td><input type="text" pattern="^[A-Za-z\d]+(?:[_%+][A-za-z\d]+)*@[a-z]+\.[a-z]{2,4}$" title="Invalid Email" name="email" require></td>
         </tr>

         <tr>
         <td><label>Username</label></td>
         <td><input type="text" name="uname" required></td>
         </tr>

         <tr>
         <td><label>Password</label></td>
         <td><input type="password" pattern="^[\dA-Za-z\W_]+$" name="password" title="uppercase lowercase nymber symbol" required></td>
         </tr>

         <tr>
         <td><label>Confrim Password</label></td>
         <td><input type="password" name="unam" required></td>
         </tr>
          
         <tr>
            <td colspan=2 align="center"><input type="submit" onclick="return check()" name= submit></td>
         </tr>

        </table>
     </form>

     <script>
        function check() {
            let pass =f.password.value;
            let cpass=f.confirmpassword.value;
            if(pass!=cpass){
            alter("Password is not identical");
            return false;
            }else{
                return true;
            }
        }
     </script>

     <?php
     if(isset($_POST['signupBtn'])){
        $firstname=$_POST['fname'];
        $lastname=$_POST['lname'];
        $gender=$_POST['gender'];
        $age=$_POST['age'];
        $email=$_POST['email'];
        $username=$_POST['uname'];
        $password=$_POST['password'];
       $sq= "INSERT INTO `signupdb`( `firstname`, `lastname`, `gender`, `age`, `email`, `username`, `password`) VALUES ('$firstname','$lastname',' $gender','$age',' $email','$username','$password')";
       $run= mysqli_query($conn,$q);
       if($run){
        echo "<script>altert('Registeration Successfully')<script>";
        echo "<script>altert('username is : .$username.and password is : .$password')<script>";
        echo "<script>window.location.href='myloginup.php'<script>";
       }
     }
     
    
     ?>





</body>
</html>