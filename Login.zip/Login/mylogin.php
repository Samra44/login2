<?php
 include("dbconnection.php");
 session_start();
 if(isset($_SESSION['username'])){
     header("location: dashboard.php");
 }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
     <form action="" method= "post">
        <label> Username</label>
        <input type="text" name="username" required><br><br>
        <label> Password</label>
        <input type="password" name="password" required id="pass"> <br><br>
        <input type="checkbox" onclick="show()">
        <label> Show Password</label>

        <input type="submit" value="Login" name="loginbtn">

     </form>
  
    <?php
    if(isset($_POST['loginbtn'])){
        $Username = $_POST['username'];
        $Password = $_POST['password'];
        $q="SELECT * FROM login WHERE Username = '$Username' and Password = '$Password'";
        $run = mysqli_query($conn,$q);
        $total_rows= mysqli_num_rows($run);
        echo $total_rows;
        if($total_rows == 1){
            $_SESSION['username']=$Username;
            $_SESSION['last_time']=time();
            header("location: dashboard.php");
        }else{
             "<script>altert('User or password is inncorrect')</script>";


    }
    
    }
    
    ?>
    <Script>
    function show(){
    let a = document.getElementById("pass");
    if(a.type =="password"){
       a.type = "text";
    }else{
        a. type = "password";
    }

    }
    </Script>


   
    
    
    
  
</body>
</html>